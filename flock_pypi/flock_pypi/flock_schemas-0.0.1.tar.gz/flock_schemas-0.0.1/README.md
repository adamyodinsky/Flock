# Flock-Schemas

## Copyright

Copyright © 2023 Adam Yodinsky. All Rights Reserved.

This software and its associated documentation are proprietary and confidential to Adam Yodinsky. Unauthorized copying, modification, distribution, or any other use of this software, in whole or in part, is strictly prohibited without the express written consent of Adam Yodinsky.

This software is provided "as is" without warranty of any kind, either express or implied, including, but not limited to, the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.

In no event shall Adam Yodinsky be liable for any claim, damages, or other liability arising from, out of, or in connection with the software or the use or other dealings in the software.
